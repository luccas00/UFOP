package secundario;

public abstract class FormaGeometrica {
	
	public abstract void desenhar();

}
