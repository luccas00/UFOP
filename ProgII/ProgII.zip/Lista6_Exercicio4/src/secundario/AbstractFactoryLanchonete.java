package secundario;

public abstract class AbstractFactoryLanchonete {
	
	public abstract Sanduiche getSanduiche();

}
