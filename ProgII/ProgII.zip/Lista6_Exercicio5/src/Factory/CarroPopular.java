package Factory;

public abstract class CarroPopular {
	
	protected String proprietario;
	protected String placa;
	protected String chassi;
	
	public abstract void exibirInfoPopular();

}
