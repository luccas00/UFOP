package Factory;

public abstract class CarroSedan {
	
	protected String proprietario;
	protected String placa;
	protected String chassi;
	
	public abstract void exibirInfoSedan();

}
