package secundario;

public interface MedidorCelsius {
	
	public double medirTemperatura();

}
