package secundario;

public interface Sanduiche {
	
	public String getDescricao();

}
