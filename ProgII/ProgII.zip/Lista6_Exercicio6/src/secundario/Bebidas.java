package secundario;

public interface Bebidas {
	
	public String getDescricao();

}
