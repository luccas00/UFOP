package secundario;

public interface LanchoneteFactory {
	
	public Bebidas criarBebida();
	public Sanduiche criarSanduiche();
	
}
