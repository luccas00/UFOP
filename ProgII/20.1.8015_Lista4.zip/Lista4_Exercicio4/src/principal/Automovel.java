package principal;

public class Automovel extends Veiculo {
	
	public Automovel(String nome)
	{
		super(nome);
	}
	
	public void mudarOleo()
	{
		
	}

	@Override
	public void listarVerificacoes() {
		// TODO Auto-generated method stub

	}

	@Override
	public void ajustar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void limpar() {
		// TODO Auto-generated method stub

	}

}
