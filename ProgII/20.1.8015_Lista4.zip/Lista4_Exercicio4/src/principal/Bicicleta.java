package principal;

public class Bicicleta extends Veiculo {
	
	public Bicicleta(String nome)
	{
		super(nome);
	}

	@Override
	public void listarVerificacoes() {
		// TODO Auto-generated method stub

	}

	@Override
	public void ajustar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void limpar() {
		// TODO Auto-generated method stub

	}

}
