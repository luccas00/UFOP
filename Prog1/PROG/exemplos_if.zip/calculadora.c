#include <stdio.h>
#include <math.h>

int main(){
    char operador;
    float num1, num2, resultado;

    printf("Digite o operador:\n");
    scanf("%c", &operador);


    if(operador == 'r'){
        printf("Digite o numero 1:\n");
        scanf("%f", &num1);
    }
    else if(operador == '+' || operador == '-' || operador == '*' || operador == '/' || operador == 'e'){
        printf("Digite o numero 1:\n");
        scanf("%f", &num1);
        printf("Digite o numero 2:\n");
        scanf("%f", &num2);
    }
    else{
        printf("Operador invalido");
    }

    if(operador == '+'){
        resultado = num1+num2;
        printf("%f + %f = %f", num1, num2, resultado);
    }
    else if(operador == '-'){
        resultado = num1-num2;
        printf("%f - %f = %f", num1, num2, resultado);
    }
    else if(operador == '*'){
        resultado = num1*num2;
        printf("%f * %f = %f", num1, num2, resultado);
    }
    else if(operador == 'r'){
        resultado = sqrt(num1);
        printf("r %f = %f", num1, resultado);
    }


    return 0;
}
