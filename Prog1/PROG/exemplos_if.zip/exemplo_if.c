#include <stdio.h>
#include <math.h>

int main(){
    float nota;
    int faltas;
    printf("Digite a nota do aluno:\n");
    scanf("%f", &nota);
    printf("Digite o numero de faltas");
    scanf("%d", &faltas);
    if(nota > 5.9 && faltas <=18){
        printf("Aluno aprovado!");
    }
    else{
        printf("Aluno reprovado.");
    }
    return 0;
}
