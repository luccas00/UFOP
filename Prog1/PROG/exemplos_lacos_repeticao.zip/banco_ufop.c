#include <stdio.h>

//Homework
// 1 - inserir a checagem de saldo antes do saque
// 2 - inserir a opçao de limite. O cliente comecaria com um limite de 500 reais
// a conta poderia estar negativa ate o limite

int main(){
    double saldo=0.0, valor;
    int opcao;

    printf("**********Bem vindo ao banco da UFOP**********\n");
    do{
        printf("\tDigite 1 para saldo\n");
        printf("\tDigite 2 para deposito\n");
        printf("\tDigite 3 para saque\n");
        printf("\tDigite qualquer outro numero para sair\n");
        scanf("%d", &opcao);
        // switch faz a selcao para variaveis do tipo int e char
        switch(opcao){
            case 1:
                printf("Seu saldo e: R$ %.2f\n", saldo);
                break;
            case 2:
                printf("Qual valor do deposito\n");
                scanf("%lf", &valor);
                saldo += valor;
                break;
            case 3:
                printf("Qual o valor do saque");
                scanf("%lf", &valor);
                saldo -= valor;
                break;
            default:
                printf("Obrigado por usar o banco da UFOP!");
        }
    }
    while(opcao >= 1  && opcao <= 3);

    return 0;
}
