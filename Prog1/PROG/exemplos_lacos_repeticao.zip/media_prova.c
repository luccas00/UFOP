#include <stdio.h>

int main(){
    float soma = 0.0, nota, media;
    int numero_alunos;

    printf("Qual e o tamanho da turma");
    scanf("%d", &numero_alunos);

    for(int i = 0; i < numero_alunos; i++){
        printf("Digite a nota do aluno %d\n", i);
        scanf("%f", &nota);
        soma = soma + nota; //soma += nota;
    }
    media = soma/numero_alunos;
    printf("A media da turma foi: %.2f", media);
    return 0;
}
/*
int main(){
    float soma = 0.0, nota, media;
    int numero_alunos = 0;
    char continua = 's';
    while(continua == 's' || continua == 'S'){
        numero_alunos = numero_alunos +1; // numero_alunos+=1; // numero_alunos ++;
        printf("Digite a nota do aluno %d\n", numero_alunos);
        scanf("%f", &nota);
        soma = soma + nota; //soma += nota;
        printf("Digitar nota de mais um aluno? Digite S ou s para sim. Outra tecla para sair\n");
        scanf(" %c", &continua);
    }
    media = soma/numero_alunos;
    printf("A media da turma foi: %.2f", media);
    return 0;
}
*/
